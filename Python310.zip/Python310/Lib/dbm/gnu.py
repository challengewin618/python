"""Provide the _gdbm module as a dbm submodule."""

from _gdbm import *
